import CustomInput from "./CustomInput";
import { Formik,Form } from "formik";
import { advancedSchema } from "../schemas";
import CustomSelect from "./CustomSelect";
import CustomCheckBox from "./CustomCheckBox";
import { Link } from "react-router-dom";

const onSubmit=async(values,actions)=>{


    console.log(values)
    console.log(actions)

    await new Promise((resolve)=>{
        console.log()
        setTimeout(resolve,2000)
        
    })
    actions.resetForm();

};

function Portal() {
    return (
    <>
    <Formik
    initialValues={{ username: '', universty: '', isAccepted:false}}
    onSubmit={onsubmit}
    validationSchema={advancedSchema}
     >
       {({isSubmitting}) => (
         <Form>
            <CustomInput 
            label={"Kullanıcı adı"}
            type='text'
            name='username'
            placeholde="Kullanıcı adınızı giriniz"
            
            />
            <CustomSelect
            label='Okulunuz'
            type='sele'
            name='universty'
            placeholder="Üniversitenizi seçiniz" 
            >
                <option value="">Lütfen Üniversitenizi seçiniz</option>
                <option value="bogazici">Boğaziçi Üniversitesi</option>
                <option value="gsu">Galatasaray Üniversitesi</option>
                <option value="odtü">Orta Doğu Teknik Üniversitesi</option>
                <option value="itü">İstanbul Teknik Üniversitesi</option>
            </CustomSelect>
            <CustomCheckBox type="checkbox" name="isAccepted"/>
            <button disabled={isSubmitting} type="submit">Kaydet</button>
            <Link className="formLink" to={"/"}>Ana forma git</Link>
           
         </Form>
       )}
     </Formik>
     </>
    );   
       
      
}

export default Portal;
